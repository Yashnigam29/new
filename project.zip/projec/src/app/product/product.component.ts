import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductserveService } from '../productserve.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers:[ProductserveService]
})
export class ProductComponent implements OnInit {
  products:Product[];
  product:Product=new Product();
  constructor(private ProductserveService:ProductserveService) { }

  ngOnInit() {
    this.ProductserveService.getProduct().subscribe((productData)=> this.products=productData);
  }
  remove(proid:Number):void{
    console.log("remove button"+proid);
    this.ProductserveService.removeproduct(proid).subscribe((proData)=> this.ProductserveService.getProduct().subscribe((data)=>this.products=data),
    (error)=>{
      console.error(error);
    })
    // this.ProductserveService.removeproduct(proid);
    // this.employeeservice.getAllEmp().subscribe((taskData)=> this.emps=taskData);
    // console.log(JSON.stringify(this.products));
  }
  update(pro:Product):void{
          console.log("update button enconter");
          Object.assign(this.product,pro);
  }

}
