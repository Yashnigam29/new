export class Product1 {
    id:number;
    proName:string;
    prodescription:string;
    price:number;
}
