export class Product {
    id:number;
    proName:string;
    prodescription:string;
    price:number;
}
