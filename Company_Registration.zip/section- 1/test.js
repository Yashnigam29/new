// Function to Calculate Module Score
function Calculate() {
    var x = document.getElementById("i1").value;
    var y = document.getElementById("i2").value;
    var z = document.getElementById("i3").value;
    var m = document.getElementById("name").value;
    var n = document.getElementById("number").value;
    var c = (70 / 100) * x + (15 / 100) * y + + (15 / 100) * z;
    if (document.forms['form1'].mpt.value === "" || document.forms['form1'].mtt.value === "" || document.forms['form1'].assignment.value === "" || document.forms['form1'].number1.value === "" || document.forms['form1'].name1.value === "" || document.forms['form1'].t1.value === "" || document.forms['form1'].t2.value === "") {

        return false;
    }

    return alert("Your name: " + m + "\n" + "Your roll number is: " + n + "\n" + "Your total mark is: " + c + "\n");
}

// Function to get the values in the module name drop down which are dependent on domain name
function populate(s1, s2) {
    var s1 = document.getElementById(s1);
    var s2 = document.getElementById(s2);
    s2.innerHTML = "";
    if (s1.value == "JEE") {
        var optionArray = ["Not Selected|Select", "Core Java|Core Java", "Servlet-JSP|Servlet-JSP", "Spring|Spring"];
    } else if (s1.value == ".NET") {
        var optionArray = ["Not selected|Select", "C#|C#", "ADO.NET|ADO.NET", "ASP.NET|ASP.NET"];
    }
    for (var option in optionArray) {
        var pair = optionArray[option].split("|");
        var newOption = document.createElement("option");
        newOption.value = pair[0];
        newOption.innerHTML = pair[1];
        s2.options.add(newOption);
    }
}

//Function to have Employee Number of the trainee to be of 6 digit number 
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}


//Function to accept alphabet and blank space only in employee name
function fun1() {
    var a = document.getElementById("name").value;
    var b = /^[a-zA-Z\s]+$/
    if (a.match(b)) {
        return true;
    }
    else {
        alert("Only alphabets are allowed");
    }
}
