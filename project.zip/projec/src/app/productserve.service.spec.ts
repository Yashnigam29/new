import { TestBed, inject } from '@angular/core/testing';

import { ProductserveService } from './productserve.service';

describe('ProductserveService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProductserveService]
    });
  });

  it('should be created', inject([ProductserveService], (service: ProductserveService) => {
    expect(service).toBeTruthy();
  }));
});
