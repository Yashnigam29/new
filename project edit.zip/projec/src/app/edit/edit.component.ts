import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductserveService} from '../productserve.service'
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css'],
  providers:[ProductserveService]
})
export class EditComponent implements OnInit {
//  products:Product[]=[];
  product:Product=new Product();
  constructor(private ProductserveService:ProductserveService) { 
   
  }

  ngOnInit() {
    // this.ProductserveService.getProduct().subscribe((productData)=> this.products=productData);
    // Object.assign(this.product)

    
  }
edit():void{
//   console.log("update button entered");
//   Object.assign(this.product,this.ProductserveService.getProduct().subscribe((data)=>this.products=data));

//   this.ProductserveService.updatepro(this.product).subscribe((ProData)=> this.ProductserveService.getProduct().subscribe((data)=>this.products=data),
//   (error)=>{
//     console.error(error);
//   })

 }
}
